sys_prompt = (
    "Based on the triplets from a knowledge graph, please answer the given question. "
    "Please keep the answers as simple as possible and return all the possible answers "
    """as a list, each with a prefix "ans:"."""
)
cot_prompt = (
    'Format your above answers by listing each answer on a separate line, starting with the prefix "ans:".'
    # " Put your most confident answer first."
    # "2. For each answer, provide reasoning and a likelihood score based on the given triplets."
    # "3. Do not add any new answers."
    # "3. Remove irrelevant answers according to your knowledge, but do not add any additional answers."
)


sys_prompt_gpt = (
    "Based on the triplets retrieved from a knowledge graph, please select relevant triplets for answering the question."
    ' Please return formatted triplets as a list, each prefixed with "evidence:".'
)
cot_prompt_gpt = cot_prompt


sys_prompt_rm_rank = sys_prompt
cot_prompt_rm_rank = (
    "Format your above answers as follows:\n"
    "First, remove wrong answers according to your knowledge.\n"
    'Second, list each answer on a separate line, starting with the prefix "ans:".\n'
    "Finally, put your most confident answer first."
)


sys_prompt_simp = (
    "Based on the triplets from a knowledge graph, please answer the given question."
)
cot_prompt_simp = (
    'Format your answers by listing each answer on a separate line, starting with the prefix "ans:".'
)


# cot_prompt = (
#     "Format your above answers as follows: "
#     '1. List each answer on a separate line, starting with the prefix "ans:". '
#     "2. Put your most confident answer first. "
#     "3. Remove wrong answers according to your knowledge. "
#     "4. If no answer was found from the given triplets, provide answers based on your knowledge, "
#     'each with a prefix "ans:" as well.'
# )


# cot_prompt = (
#     "Format your above answers as follows: "
#     '1. List each answer on a separate line, starting with the prefix "ans:". '
#     "2. Put your most confident answer first. "
#     "3. Remove irrelevant answers according to your knowledge, but do not add any additional answers."
# )


# cot_prompt = (
#     "Format your above answers as follows: "
#     "First, remove irrelevant and wrong answers according to the triplets and your knowledge. "
#     "Second, put your most confident answer first. "
#     'Third, list each answer on a separate line, starting with the prefix "ans:". '
# )

icl_sys_prompt = (
    "Based on the triplets retrieved from a knowledge graph, please answer the question."
    ' Please return formatted answers as a list, each prefixed with "ans:".'
)

# icl_cot_prompt = (
#     # "If no answer is found, please provide an answer according to your common sense. "
#     # "Please keep the answer as simple as possible."
#     #  'Format your answers by listing each answer on a separate line, starting with the prefix "ans:".'
#     #  " Use the entity names as they appear in the knowledge graph as your answers."
#     #  f" Again, the question is: {prompts['question']}"
#     # 'If there is no sufficient information to answer the question, return "ans: not available".'
#     "Let's think step by step."
#     ' Return the most possible answers by listing each answer on a separate line, starting with the prefix "ans:".'
#         # 'Format your above answers by listing each answer on a separate line, starting with the prefix "ans:".'
#     ' Otherwise, if there is no sufficient information to answer the question, return "ans: not available".'

# #    'If there is no sufficient information to answer the question, return "ans: not available".'
# #    'Otherwise, return the most possible answers, each prefixed with "ans:".'

# )

icl_cot_prompt = (
    "Let's think step by step.\n"
    'List each answer on a separate line, starting with the prefix "ans:".\n'
    "Use entity names exactly as they appear in the triplets.\n"
    "If the triplets mention relevant entities but do not directly state the answer, "
    "infer the most likely answer supported by the triplets and your knowledge.\n"
    "You must always provide at least one answer. Do not refuse to answer."
)

# Stronger fallback prompt used when DC second-round is triggered
dc_fallback_prompt = (
    "Please look at the triplets again carefully and provide your best answer.\n"
    'List each answer on a separate line with the prefix "ans:".\n'
    "Even if you are not fully certain, provide the most likely answer "
    "based on the available triplets and your knowledge.\n"
    "Do not say the information is unavailable or unknown."
)

icl_cot_prompt_post = (
    # "If no answer is found, please provide an answer according to your common sense. "
    # "Please keep the answer as simple as possible."
    #  'Format your answers by listing each answer on a separate line, starting with the prefix "ans:".'
    #  " Use the entity names as they appear in the knowledge graph as your answers."
    #  f" Again, the question is: {prompts['question']}"
    # 'If there is no sufficient information to answer the question, return "ans: not available".'
    'Return the most possible answers based on the given triplets by listing each answer on a separate line, starting with the prefix "ans:".'
        # 'Format your above answers by listing each answer on a separate line, starting with the prefix "ans:".'
    ' Otherwise, if there is no sufficient information to answer the question, return "ans: not available".'
    " Let's think step by step."

#    'If there is no sufficient information to answer the question, return "ans: not available".'
#    'Otherwise, return the most possible answers, each prefixed with "ans:".'

)


icl_user_prompt = """Triplets:
(Lou Seal,sports.mascot.team,San Francisco Giants)
(San Francisco Giants,sports.sports_team.championships,2012 World Series)
(San Francisco Giants,sports.sports_championship_event.champion,2014 World Series)
(San Francisco Giants,time.participant.event,2014 Major League Baseball season)
(San Francisco Giants,time.participant.event,2010 World Series)
(San Francisco Giants,time.participant.event,2010 Major League Baseball season)
(San Francisco Giants,sports.sports_team.championships,2014 World Series)
(San Francisco Giants,sports.sports_team.team_mascot,Crazy Crab)
(San Francisco Giants,sports.sports_team.championships,2010 World Series)
(San Francisco Giants,sports.professional_sports_team.owner_s,Bill Neukom)
(San Francisco Giants,time.participant.event,2012 World Series)
(San Francisco,sports.sports_team_location.teams,San Francisco Giants)
(San Francisco Giants,sports.sports_team.arena_stadium,AT&T Park)
(AT&T Park,location.location.events,2012 World Series)
(m.011zsc4_,organization.leadership.organization,San Francisco Giants)
(San Francisco Giants,sports.sports_team.previously_known_as,New York Giants)
(AT&T Park,location.location.events,2010 World Series)
(Crazy Crab,sports.mascot.team,San Francisco Giants)
(New York Giants,baseball.baseball_team.league,National League)
(San Francisco Giants,sports.sports_team.colors,Black)
(San Francisco Giants,sports.sports_team.previously_known_as,New York Gothams)
(m.0k079qm,base.schemastaging.team_training_ground_relationship.team,San Francisco Giants)
(m.0k079ry,base.schemastaging.team_training_ground_relationship.team,San Francisco Giants)
(2010 World Series,time.event.locations,AT&T Park)
(San Francisco Giants,time.participant.event,2012 Major League Baseball season)
(San Francisco Giants,baseball.baseball_team.league,National League)
(m.0crtd80,sports.sports_league_participation.league,National League West)
(San Francisco Giants,sports.sports_team.location,San Francisco)
(San Francisco Giants,sports.sports_team.sport,Baseball)
(m.05n6dtn,baseball.baseball_team_stats.team,San Francisco Giants)


Question:
What year did the team with mascot named Lou Seal win the World Series?"""

icl_ass_prompt = """To find the year the team with mascot named Lou Seal won the World Series, I need to:
1. Identify the team with mascot Lou Seal
2. Find which World Series they won

From the triplets: (Lou Seal, sports.mascot.team, San Francisco Giants) — so the team is San Francisco Giants.

The triplets show San Francisco Giants won:
- (San Francisco Giants, sports.sports_team.championships, 2010 World Series)
- (San Francisco Giants, sports.sports_team.championships, 2012 World Series)
- (San Francisco Giants, sports.sports_team.championships, 2014 World Series)

ans: 2010 World Series
ans: 2012 World Series
ans: 2014 World Series"""


noevi_sys_prompt = (
    "Please answer the question."
    ' Please return formatted answers as a list, each prefixed with "ans:".'
)


noevi_cot_prompt = (
    # "If no answer is found, please provide an answer according to your common sense. "
    # "Please keep the answer as simple as possible."
    #  'Format your answers by listing each answer on a separate line, starting with the prefix "ans:".'
    #  " Use the entity names as they appear in the knowledge graph as your answers."
    #  f" Again, the question is: {prompts['question']}"
    # 'If there is no sufficient information to answer the question, return "ans: not available".'
    "Let's think step by step."
    ' Return the most possible answers by listing each answer on a separate line, starting with the prefix "ans:".'
        # 'Format your above answers by listing each answer on a separate line, starting with the prefix "ans:".'
    ' Otherwise, if there is no sufficient information to answer the question, return "ans: not available".'

#    'If there is no sufficient information to answer the question, return "ans: not available".'
#    'Otherwise, return the most possible answers, each prefixed with "ans:".'

)


# ============================================================
# Ablation: baseline (main-branch) versions of icl_cot_prompt and
# icl_ass_prompt. Used only when --use_baseline_prompts is set.
# Content matches the prompts on the `main` branch exactly.
# ============================================================

baseline_icl_cot_prompt = (
    "Let's think step by step."
    ' Return the most possible answers based on the given triplets by listing each answer on a separate line, starting with the prefix "ans:".'
    ' Otherwise, if there is no sufficient information to answer the question, return "ans: not available".'
)

baseline_icl_ass_prompt = """To find the year the team with mascot named Lou Seal won the World Series, we need to find the team with mascot named Lou Seal and then find the year they won the World Series.

From the triplets, we can see that Lou Seal is the mascot of the San Francisco Giants.

Now, we need to find the year the San Francisco Giants won the World Series.

From the triplets, we can see that San Francisco Giants won the 2010 World Series and 2012 World Series and 2014 World Series.

So, the team with mascot named Lou Seal (San Francisco Giants) won the World Series in 2010, 2012, and 2014.

Therefore, the formatted answers are:

ans: 2014 (2014 World Series)
ans: 2012 (2012 World Series)
ans: 2010 (2010 World Series)"""


# ============================================================
# Answer-then-Verify baseline prompts.
# Used ONLY when --enable_answer_then_verify_baseline is set.
# The verifier inspects the question + triplets + candidate answer
# and can: (1) keep the candidate, (2) correct it, or (3) mark as
# "ans: not available" when the triplets do not support any answer.
# Intentionally lightweight: no ICL shots, no multi-round dialogue.
# ============================================================

answer_verify_sys_prompt = (
    "You are a verifier for knowledge-graph question answering. "
    "Given a question, the supporting triplets, and a candidate answer, "
    "decide whether to KEEP the candidate, CORRECT it using only the triplets, "
    "or mark it as NO ANSWER when the triplets do not support any answer. "
    "Do not use external knowledge beyond what the triplets provide."
)

answer_verify_instruction = (
    "Verify the candidate answer against the triplets above.\n"
    "- If the candidate is supported by the triplets, keep it as-is.\n"
    "- If the candidate is wrong or incomplete, output the correct answer(s) using only the triplets.\n"
    '- If the triplets do not support any answer, output a single line "ans: not available".\n'
    'Return the final answer(s) as one or more lines, each starting with the prefix "ans:". '
    "Do not include explanations or reasoning in the final output."
)